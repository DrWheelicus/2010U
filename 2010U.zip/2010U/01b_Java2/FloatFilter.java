public interface FloatFilter {
    boolean match(float value);
}
